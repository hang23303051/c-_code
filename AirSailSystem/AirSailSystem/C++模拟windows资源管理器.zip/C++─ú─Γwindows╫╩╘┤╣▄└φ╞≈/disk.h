#pragma once
#include<iostream>
#include<string>
using namespace std;

class disk
{
public:
	string dname;
	float dsize;
	float unusedspace;
public:
	disk()
	{
		dname = "";
		dsize = 0.0f;
		unusedspace = 0.0f;
	}
	disk(string _dname, float _dsize = 0.0f, float _unusedspace = 0.0f)
	{
		dname = _dname;
		dsize = _dsize;
		unusedspace = _unusedspace;
	}
};