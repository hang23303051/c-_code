#pragma once
#include<iostream>
#include<string>
using namespace std;

class file
{
public:
	string fname;
	string type;
	string createtime;
	float fsize;
public:
	file()
	{
		fname = "";
		type = "";
		createtime = "";
		fsize = 0.0f;
	}
	file(string _fname, string _type = "", string _createtime = "", float _fsize = 0.0f)
	{
		fname = _fname;
		type = _type;
		createtime = _createtime;
		fsize = _fsize;
	}
};