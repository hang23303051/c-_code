#pragma once
#include<iostream>
#include<string>
using namespace std;

class catalog
{
public:
	string cname;
	string savetime;
	float csize;
	int number;
public:
	catalog()
	{
		cname = "";
		savetime = "";
		csize = 0.0f;
		number = 0;
	}
	catalog(string _cname, string _savetime = "", float _csize = 0.0f, int _number = 0)
	{
		cname = _cname;
		savetime = _savetime;
		csize = _csize;
		number = _number;
	}
};